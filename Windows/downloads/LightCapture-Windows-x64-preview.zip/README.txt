﻿轻截 Windows x64 | 工程预览

原生 Win32，默认 F2，可在设置选择 F1 或 Ctrl+A。
长截图：框选后点击长截图（或 L），直接用触控板双指或滚轮滚动原页面。Enter 保存，Esc 取消。
这是未签名便携工程包，不是正式安装版、没有一键更新。Windows 桌面实机手势、录屏音画、多屏和常驻内存尚未验收。请勿关闭系统安全功能或为本包绕过警告。
源码和状态：https://github.com/Jerryb0t/LightCapture/tree/windows-preview/Windows

LightCapture.exe SHA-256: c8388a154d466553ee525f0b3f914497cf01c1b76b98671b0b2f177e7d9296e1
