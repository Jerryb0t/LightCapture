﻿轻截 Windows x64 | 工程预览

原生 Win32，默认 F2，可在设置选择 F1 或 Ctrl+A。
长截图：框选后点击长截图（或 L）；仅留不挡操作的细边框，双指或滚轮直接滚动原页面。Enter 保存，Esc 取消。
这是未签名便携工程包，不是正式安装版、没有一键更新。Windows 桌面实机手势、录屏音画、多屏和常驻内存尚未验收。请勿关闭系统安全功能或为本包绕过警告。
源码和状态：https://github.com/Jerryb0t/LightCapture/tree/windows-preview/Windows

LightCapture.exe SHA-256: a65d49d581dfcdde134dc6fe71f033628c98cf84963ea5cc7c93012fecbcb6eb
