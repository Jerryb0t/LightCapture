轻截 Windows x64 | 工程预览

原生 Win32，默认 F2，可在设置选择 F1 或 Ctrl+A。
这是未签名便携工程包，不是正式安装版、没有一键更新。Windows 桌面、录屏音画、多屏和常驻内存尚未实机验收。请勿关闭系统安全功能或为本包绕过警告。
源码和状态：https://github.com/Jerryb0t/LightCapture/tree/windows-preview/Windows

LightCapture.exe SHA-256: e3a3df47407591f99767d2d6104da9ce396569ea657b186130f905d41347ab9d
