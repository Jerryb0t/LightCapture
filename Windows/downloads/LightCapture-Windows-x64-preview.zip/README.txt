﻿轻截 Windows x64 | 工程预览

原生 Win32，默认 F2，可在设置选择 F1 或 Ctrl+A。
长截图：打开选区后点击左上角长截图或按 L。悬停吸附窗口后单击，或拖框后松手。只留不挡操作的细边框，双指或滚轮滑动原页面，Enter 保存，Esc 取消。没拼进新内容时不会生成长图。
这是未签名便携工程包，不是正式安装版、没有一键更新。Windows 桌面实机手势、录屏音画、多屏和常驻内存尚未验收。请勿关闭系统安全功能或为本包绕过警告。
源码和状态：https://github.com/Jerryb0t/LightCapture/tree/windows-preview/Windows

LightCapture.exe SHA-256: 77cc983cb3c47a6d41bb083231bcd11fbe7a864b5d70c84c26e521a3812ce3f0
